<div id="footer">
		<p>Copyright &copy; Adrian West 2012 | Designed by <a href="http://www.colycomputerhelp.co.uk/">Adrian West</a> | Valid <a href="http://jigsaw.w3.org/css-validator/">CSS</a> &amp; 
		<a href="http://validator.w3.org/">HTML5</a></p>
</div>