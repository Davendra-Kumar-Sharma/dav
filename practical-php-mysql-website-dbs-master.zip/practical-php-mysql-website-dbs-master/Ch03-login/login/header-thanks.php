<div id="header">
<h1>This is the header</h1>
<div id="reg-navigation">
	<p>&nbsp;</p>
	<ul>
		<li><a href="index.php">Home Page</a></li>
	</ul>
</div>
</div>

