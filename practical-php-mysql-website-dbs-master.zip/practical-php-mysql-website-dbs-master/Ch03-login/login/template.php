<!doctype html>
<html lang=en>
<head>
<title>Template for an interactive database</title>
<meta charset=utf-8>
<link rel="stylesheet" type="text/css" href="includes.css">
</head>
<body>
<div id='container'>
<?php include('header-for-template.php'); ?>
<?php include('nav.php'); ?>
<?php include('info-col.php'); ?>
	<div id='content'><!--Start of page content.-->
<h2>This is the Home Page</h2>
<p>The home page content. The home page content. The home page content. The home page content. The home page content. <br>The home page content. The home page content. The home page content. The home page content. <br>The home page content. The home page content. <br>The home page content. The home page content. The home page content. </p>
	<!--End of the page content.--></div>
</div>	
<?php include('footer.php'); ?>
</body>
</html>