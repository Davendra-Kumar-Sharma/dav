<div id="header-admin">
<h1>This is the admin header</h1>
<div id="reg-navigation">
		<ul>
			<li><a href="logout.php">Logout</a></li>
			<li><a href="register-view_users-page.php">View Members</a></li>
			<li><a href="#">Search</a></li>
			<li><a href="register-password.php">New Password</a></li>
		</ul>
	</div>
</div>
