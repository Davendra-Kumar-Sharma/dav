<!doctype html>
<html lang="en">
<head>
<title>Register page2</title>
<meta charset=utf-8>
<link rel="stylesheet" type="text/css" href="includes.css">
</head>
<body>
<div id="container">
<?php include("includes/header.php"); ?>
<?php include("includes/nav.php"); ?>
<?php include("includes/info-col.php"); ?>
	<div id="content"><!-- Start of page content. -->
<h2>This is page Five</h2>
<p>The page five content. The page five content. The page five content.<br>The page 
five content. The page five content. The page five content.<br>The page five content. The page 
five content. The page five content.<br>The page five content. The page five content. The page 
five content.</p>
	<!-- End of page five content. --></div>
</div>	
<?php include("includes/footer.php"); ?></body>
</html>