<html>
<?php echo("<h2>Now you can see me properly</h2>"); ?>
</html>
