<!doctype html>
<html lang="en">
<head>
<title>Register page2</title>
<meta charset=utf-8>
<link rel="stylesheet" type="text/css" href="includes.css">
</head>
<body>
<div id="container">
<?php include("header.php"); ?>
<?php include("nav.php"); ?>
<?php include("info-col.php"); ?>
	<div id="content"><!-- Start of the page-specific content. -->
<h2>This is page Four</h2>
<p>The page four content. The page four content. The page four content.<br>The page 
four content. The page four content. The page four content.<br>The page four content. The page 
four content. The page four content.<br>The page four content. The page four content. The page 
four content.</p>
	<!-- End of the page-specific content. --></div>
</div>	
	<div id="footer">
		<p style="height: 19px">Copyright &copy; Adrian West 2012 | Designed by <a href="http://www.colycomputerhelp.co.uk/">Adrian West</a> | Valid <a href="http://jigsaw.w3.org/css-validator/">CSS</a> &amp; 
		<a href="http://validator.w3.org/">HTML5</a></p>
	</div>
</body>
</html>