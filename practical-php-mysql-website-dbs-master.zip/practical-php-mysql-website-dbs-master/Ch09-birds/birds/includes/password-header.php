<div id="header">
<h1>The Devon Bird Reserves</h1>
<div id="reg-navigation">
	<ul>
		<li><a href="register-password.php">Erase Entries</a></li>
		<li><a href="index.php">Cancel</a></li>
	</ul>
</div>
</div>

