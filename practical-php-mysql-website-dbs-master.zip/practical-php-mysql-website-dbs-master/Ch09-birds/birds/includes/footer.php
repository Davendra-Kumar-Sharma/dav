<div id="footer">
		<p>Copyright &copy; Adrian West 2013</p>
</div>