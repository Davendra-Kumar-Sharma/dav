<!doctype html>
<html lang=en>
<head>
<title>Message board template</title>
<meta charset=utf-8>
<link rel="stylesheet" type="text/css" href="msgboard.css">
<style type="text/css">
#header #tab-navigation ul { margin-left:58px; }
</style>
</head>
<body>
<div id='container'>
<?php include('includes/header.php'); ?>
<?php include('includes/info-col.php'); ?>
	<div id='content'><!--Start of page content-->
<h2>This is the message board template</h2>
<p>The message board content. The message board content. The message board content. The message board content. The message board content. <br>The message board content. The message board content. The message board content. The message board content. <br>The message board content. The message board content. <br>The message board content. The message board content. The message board content. </p>
	<!--End of the template content--></div>
</div>	
<?php include('includes/footer.php'); ?>
</body>
</html>