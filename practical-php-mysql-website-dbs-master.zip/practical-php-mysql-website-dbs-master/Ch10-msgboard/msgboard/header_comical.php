<div id="header">
<h1>Quick Quotes</h1>
<div id="tab-navigation">
	<ul>
		<!--<li><a href="login.php">Login</a></li>-->
		<li><a href="logout.php">Logout</a></li>
		<!--<li><a href="safer-register-page.php">Register</a></li>
		<li><a href="post.php">New Thread</a></li>-->
		<li><a href="forum_w.php">Wise Quotes</a></li>-->
		<li><a href="index.php">Home page</a></li>
	</ul>
</div>
