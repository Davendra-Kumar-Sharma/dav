<?php
<h3>This is the information column</h3>
<p>Web design by <br>A W West</p>
<p>&nbsp;</p>
?>